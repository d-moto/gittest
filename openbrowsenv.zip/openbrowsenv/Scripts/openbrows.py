from selenium import webdriver
from selenium.webdriver.chrome.service import Service
import time

# ウェブサイトのURL
url = 'https://tenki.jp/lite/forecast/8/41/7320/38205/10days.html'

# Chrome WebDriverのパス
driver_path = "C:/Users/mokos/AppData/Local/SeleniumBasic/chromedriver.exe" # あなたの環境に合わせてパスを修正してください

# Serviceオブジェクトの作成
service = Service(executable_path=driver_path)

# Chrome WebDriverのインスタンスを作成
driver = webdriver.Chrome(service=service)

# 指定したURLを開く
driver.get(url)

# 30分（1800秒）ごとにページをリロードする
while True:
    time.sleep(10)  # 10秒待機
    driver.refresh()  # ページをリロード
